<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Ing. ">
    	<link rel="icon" type="imagen/jpg" href="../imagenes/favicon.ico"/>    <!--favicon-->
    <meta name="generator" content="Jekyll v4.1.1">
    <title>COLEGIO BAJA CALIFORNIA - Inscripción </title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
   
    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
     <style type="text/css">
      #regiration_form fieldset:not(:first-of-type) {
        display: none;
      }
    </style>
    <!-- Editor de  Estilos CSS -->
<link href="css/style.css" rel="stylesheet">

  </head>
  <body class="bg-ligth">
    <div class="container">
      <div class="py-5 text-center">
        <img class="d-block mx-auto mb-4" src="imagenes/logo.png" alt="" width="120" height="120">
        <h1>Solicitud de Inscripción</h1>

        <p class="lead">En esta sección podras ingresar tus datos personales y familiares.</p>
        <h1>Registro de usuarios paso a paso</h1>
        <div class="">
            
            </div>
                  </div>
  


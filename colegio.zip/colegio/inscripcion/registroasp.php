
<?php 
     include 'funciones/datosConexion.php';
     
     include 'inc/layout/header.php'; 
?>

  <?php include 'inc/layout/formulario.php'; ?>

<?php

include 'inc/layout/footer.php'; 

?>

<?php 
     include 'funciones/datosConexion.php';
     
     include 'inc/layout/header.php'; 
?>

  <?php include 'inc/layout/formularioAlumno.php'; ?>

<?php

include 'inc/layout/footer.php'; 

?>
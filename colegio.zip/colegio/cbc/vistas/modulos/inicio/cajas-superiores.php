<?php

$item = null;
$valor = null;
$orden = "id";


?>




<center>
   

    <div class="t-widget t-grid" id="Mensajes">
    <table cellspacing="0">
    <colgroup>
    <col>
    </colgroup>
    <thead class="t-grid-header">
      <tr>
        <th class="t-header" scope="col">
        
          </th></tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <p style="text-align:center;">
                  <strong>
                    <span style="font-size:large;background-color:#fff200;">INSCRIPCIONES 202101</span>
                      </strong></p>
                        <p>
                          <span style="font-size:large;">El proceso de Reinscripciones 202101 dará inicio en:</span>
                          </p><ul><li><span style="font-size:large;">4 al 26 de febrero de 2021 - Kinder </span><strong><span style="font-size:large;">municipio de Tijuana</span></strong></li><li><span style="font-size:large;">5 al 26 de febrero de 2021 - Primaria y Secundaria </span><strong><span style="font-size:large;">municipio de Tijuana</span></strong><strong></strong><br></li></ul></td></tr></tbody></table><div class="t-grid-pager t-grid-bottom"><div class="t-status">
                          </div></div></div>

</center>
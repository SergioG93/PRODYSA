<?php
  $db_host = "mysql.hostinger.mx";
  $db_nombreBD = "u193840410_colegiobc"; 
  $db_usuario = "u193840410_colegiobc"; 
  $db_password = "C12345678x";
  
  /*$conexion=new mysqli($hostname,$username,$password,$database);

  if($conexion->connect_errno )
    {
    echo "los sentimos el sitio esta exprimentando problemas";

    }*/
?>

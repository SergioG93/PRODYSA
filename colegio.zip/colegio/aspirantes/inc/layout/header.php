<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    	<link rel="icon" type="imagen/jpg" href="../imagenes/favicon.ico"/>    <!--favicon-->
    <title>Colegio Baja California - Solicitud de Preinscripción</title>
    <link rel="stylesheet" href="css/style.css"> 
    <link rel="stylesheet" href="https://necolas.github.io/normalize.css/8.0.0/normalize.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
    


    <script src='//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script>
       
    <script>
		    function check(e) 
		         {
                    tecla = (document.all) ? e.keyCode : e.which;
                
                    //Tecla de retroceso para borrar, siempre la permite
                    if (tecla == 8) {
                        return true;
                    }
                
                    // Patron de entrada, en este caso solo acepta numeros y letras
                    patron = /[0-9]/;
                    tecla_final = String.fromCharCode(tecla);
                    return patron.test(tecla_final);
                 }
                 
           
		</script>
</head>
<body>
    <center>
            <img class="rounded float-left" src="img/logos/Logo.png" border="0" alt="inscripcion" id="logotipo" style="width-size:5%; padding:30px 30px;">
    </center>   
             <div class="col-12 col-lg-10">
             <h1 class="text-center" style="padding:30px">
             Solicitud de Preinscripción
             </h1>
            </div>
          
            
       
      
    
    
      <br>
      
      
<div class="pieweb text-center">
<h3 style="font-size:25px;">Colegio Baja California Ave. Universidad #709, Otay Universidad. Tijuana, B.C., México.C.P. 22427,</h3>
<h3 style="font-size:25px;">Tels: (664) 682-1222 y (664) 682-1872</h3>
    <h5>Derechos Reservados Prodysa Sistemas 2021</h5> 


</div>

</body>

</html>
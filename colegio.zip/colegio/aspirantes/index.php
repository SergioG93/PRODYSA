
<?php 
     include 'inc/funciones/funciones.php';
     include 'inc/layout/header.php';
?>


     
     <?php include 'inc/layout/formulario.php'; ?>


<?php include 'inc/layout/footer.php'; ?>

